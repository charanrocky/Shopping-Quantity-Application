export const mockItems: any[] = [
  {
    icon: '🥑',
    productName: 'Avocado',
    productId: '001',
    quantity: 2,
    price: 12,
  },
  {
    icon: '🍎',
    productName: 'Apples',
    productId: '002',
    quantity: 1,
    price: 22,
  },
  {
    icon: '🥕',
    productName: 'Carrots',
    productId: '003',
    quantity: 1,
    price: 32,
  },
];
